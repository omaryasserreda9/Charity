<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('humanitarian_cases', function (Blueprint $table): void {
            $table->id();
            $table->string('name');
            $table->string('phone', 20);
            $table->string('national_id', 20)->unique();
            $table->string('area');
            $table->text('notes')->nullable();
            $table->enum('type', ['mine', 'seasonal']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('humanitarian_cases');
    }
};
